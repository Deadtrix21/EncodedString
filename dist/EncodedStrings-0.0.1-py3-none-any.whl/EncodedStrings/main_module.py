from EncodedStrings import SyncModule, AsyncModule

class Encoding:
    def __init__(self):
        self.AsyncModule = AsyncModule()
        self.SyncModule = SyncModule()
