from setuptools import setup, find_packages

setup(
    name="EncodedStrings",
    version="0.0.1",
    author="NightMareDeadTrix",
    description="A utility for encoding strings",
    license="MIT",
    url="https://github.com/NightMareDeadTrix/EncodedString",
    packages=find_packages(),
    install_requires=[],
)

